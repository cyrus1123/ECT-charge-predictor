# Copyright (c) 2017-2019 Uber Technologies, Inc.
# SPDX-License-Identifier: Apache-2.0

"""
This module contains tools for testing new distributions and distributions for
testing new Pyro inference algorithms.
"""
